echo "This script is to setup the Raspberry Pi WiFi to WUSM-secure"
echo "!!! sudo needed to run this script!!!"

sudo ifdown wlan0
sudo killall wpa_supplicant
sudo cp /wifi_config/interfaces /etc/network/interfaces
sudo cp /wifi_config/wpa_supplicant.conf /etc/wpa_supplicant/wpa_supplicant.conf
sudo cp /wifi_config/10-wpa_supplicant /lib/dhcpcd/dhcpcd-hooks/10-wpa_supplicant
sudo ifup wlan0
